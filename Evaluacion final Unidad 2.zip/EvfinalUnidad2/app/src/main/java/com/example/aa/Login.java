package com.example.aa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Login extends AppCompatActivity {

    private EditText loginusername, loginpassword;
    private Button loginbtn;
    private TextView signuptxt;
    private ArrayList<Usuario> listausuarios;
    private Usuario usuario;
    private ListasNoticias listadenoticias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        loginusername = findViewById(R.id.loginuser);
        loginpassword = findViewById(R.id.loginpwd);
        loginbtn = findViewById(R.id.loginbtn);
        signuptxt = findViewById(R.id.signuptxt);

        listausuarios = (ArrayList<Usuario>) getIntent().getSerializableExtra("listausuarios");
        listadenoticias = (ListasNoticias) getIntent().getSerializableExtra("listanoticias");
        if(listausuarios == null){
            listausuarios = new ArrayList<Usuario>();
            listausuarios.add(new Usuario("test","test"));
        }


    }

    public void verificarLogin(View view){
        boolean inicioSesion = false;
        if(!loginusername.getText().toString().matches("")){
            if(!loginusername.getText().toString().matches("")){
                for(Usuario u : listausuarios){
                    if(u.getUsuario().matches(loginusername.getText().toString())){
                        if(u.getContrasena().matches(loginpassword.getText().toString())){
                            inicioSesion = true;
                            usuario = u;
                            break;
                        }
                    }
                }
                if(inicioSesion) {
                    Toast.makeText(this, "Bienvenido de vuelta, " + loginusername.getText(), Toast.LENGTH_SHORT).show();
                    Intent pasaractividad = new Intent(this, MainActivity.class);
                    pasaractividad.putExtra("listausuarios", listausuarios);
                    pasaractividad.putExtra("listanoticias", listadenoticias);
                    pasaractividad.putExtra("usuario", usuario);
                    startActivity(pasaractividad);
               }else{
                    Toast.makeText(this, "Usuario/Contrasenia incorrecta.", Toast.LENGTH_SHORT).show();
                    loginusername.setText("");
                    loginpassword.setText("");
                    loginusername.requestFocus();
                }
            }else{
                Toast.makeText(this, "Ingrese su contrasenia por favor.", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "Ingrese su usuario por favor.", Toast.LENGTH_SHORT).show();
        }
    }

    public void crearCuenta(View view){
        Intent pasaractividad = new Intent(this, CrearUsuario.class);
        pasaractividad.putExtra("listausuarios", listausuarios);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        startActivity(pasaractividad);
    }
}