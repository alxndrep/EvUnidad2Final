package com.example.aa;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class MisNoticias extends AppCompatActivity {

    RecyclerView misNoticias;
    AdaptadorNoticiasPropias adaptador;
    ListasNoticias listadenoticias;
    ListasNoticias misNoticiasLista;
    Usuario usuario;
    ArrayList<Usuario> listausuarios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_noticias);

        usuario = (Usuario) getIntent().getSerializableExtra("usuario");
        misNoticiasLista = new ListasNoticias();

        listadenoticias = (ListasNoticias) getIntent().getSerializableExtra("listanoticias");
        listausuarios = (ArrayList<Usuario>) getIntent().getSerializableExtra("listausuarios");
        for(NoticiasU n : listadenoticias.getLista()){
            if(n.getAutor().equals(usuario.getUsuario())){
                misNoticiasLista.agregarNoticia(n);
            }
        }


        inicializar();
    }

    public void inicializar(){
        misNoticias = findViewById(R.id.ListaMisNoticias);
        misNoticias.setLayoutManager(new LinearLayoutManager(this));
        adaptador = new AdaptadorNoticiasPropias(misNoticiasLista);
        misNoticias.setHasFixedSize(true);
        misNoticias.setItemAnimator(new DefaultItemAnimator());
        misNoticias.setAdapter(adaptador);

        final GestureDetector mGestureDetector = new GestureDetector(MisNoticias.this, new GestureDetector.SimpleOnGestureListener(){
            @Override public boolean onSingleTapUp(MotionEvent e){
                return true;
            }
        });

        misNoticias.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                try {
                    View child = misNoticias.findChildViewUnder(e.getX(), e.getY());
                    if(child != null && mGestureDetector.onTouchEvent(e)){
                        int position = misNoticias.getChildAdapterPosition(child);
                        Intent pasaractividad = new Intent(MisNoticias.this, VerNoticias.class);
                        pasaractividad.putExtra("noticia", misNoticiasLista.getLista().get(position));
                        startActivityForResult(pasaractividad, 666);

                        return true;
                    }
                }catch(Exception ex){
                    ex.printStackTrace();
                }


                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 666 && resultCode == RESULT_OK){
        }
    }

    public void devolver(View view){
        Intent pasaractividad = new Intent(this, MainActivity.class);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        pasaractividad.putExtra("usuario", usuario);
        pasaractividad.putExtra("listausuarios", listausuarios);
        startActivity(pasaractividad);
    }

    @Override
    public void onBackPressed(){
        Intent pasaractividad = new Intent(this, MainActivity.class);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        pasaractividad.putExtra("usuario", usuario);
        pasaractividad.putExtra("listausuarios", listausuarios);
        startActivity(pasaractividad);
    }
}