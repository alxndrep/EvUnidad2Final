package com.example.aa;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Adaptador extends RecyclerView.Adapter<Adaptador.Holder> {

    int contador=0;
    ListasNoticias noticias;

    public Adaptador(ListasNoticias noticias) {
        this.noticias = noticias;
    }

    @NonNull
    @Override
    public Adaptador.Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview, parent, false);
        Holder holder = new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptador.Holder holder, int position) {
        contador++;
        holder.txtnum.setText(contador + ". "+noticias.getLista().get(position).getTitulo());

        File imgfile = new File(noticias.getLista().get(position).getRuta());
        if(imgfile.exists()){
            Bitmap myBitmap = BitmapFactory.decodeFile(imgfile.getAbsolutePath());
            holder.imgview.setImageBitmap(myBitmap);
        }

        holder.txttexto.setText("- "+ noticias.getLista().get(position).getFecha());
        holder.txtautor.setText("- Autor: " + noticias.getLista().get(position).getAutor());

    }

    @Override
    public int getItemCount() {
        return noticias.getLista().size();
    }


    public static class Holder extends RecyclerView.ViewHolder{
        TextView txttexto;
        TextView txtnum;
        ImageView imgview;
        TextView txtautor;

        public Holder(View itemView){
            super(itemView);
            txtnum = itemView.findViewById(R.id.txtNum);
            txttexto = itemView.findViewById(R.id.txtview);
            imgview = itemView.findViewById(R.id.imgview);
            txtautor = itemView.findViewById(R.id.txtAutor);
        }
    }
}

