package com.example.aa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class CrearUsuario extends AppCompatActivity {

    EditText inputUsuario, inputContraseña;
    Button btnRegistrar;
    private ArrayList<Usuario> listausuarios;
    ListasNoticias listadenoticias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_usuario);

        inputUsuario = findViewById(R.id.InputUsuario);
        inputContraseña = findViewById(R.id.InputContraseña);
        btnRegistrar = findViewById(R.id.btnCrearUsuario);

        listausuarios = (ArrayList<Usuario>) getIntent().getSerializableExtra("listausuarios");
        listadenoticias = (ListasNoticias) getIntent().getSerializableExtra("listanoticias");

    }

    public void verificarUsuarioExistente(View vew){
        boolean existeUsuario = false;
        if(!inputUsuario.getText().toString().matches("")) {
            if (!inputContraseña.getText().toString().matches("")) {
                for(Usuario u : listausuarios){
                    if(u.getUsuario().matches(inputUsuario.getText().toString())){
                        existeUsuario = true;
                        break;
                    }
                }
                if(!existeUsuario){
                    Usuario newuser = new Usuario(inputUsuario.getText().toString(), inputContraseña.getText().toString());
                    listausuarios.add(newuser);
                    Toast.makeText(this, "Usuario creado correctamente.", Toast.LENGTH_SHORT).show();
                    Intent pasaractividad = new Intent(this, Login.class);
                    pasaractividad.putExtra("listausuarios", listausuarios);
                    pasaractividad.putExtra("listanoticias", listadenoticias);
                    startActivity(pasaractividad);
                }else{
                    Toast.makeText(this, "Nombre de usuario ya existente.", Toast.LENGTH_SHORT).show();
                    inputUsuario.setText("");
                    inputContraseña.setText("");
                    inputUsuario.requestFocus();
                }
            }else{
                Toast.makeText(this, "Ingrese una contrasenia por favor.", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "Ingrese un usuario por favor.", Toast.LENGTH_SHORT).show();
        }


    }


    @Override
    public void onBackPressed(){
        Intent pasaractividad = new Intent( this, Login.class);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        pasaractividad.putExtra("listausuarios", listausuarios);
        startActivity(pasaractividad);
    }
}