package com.example.aa;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;

public class AdaptadorNoticiasPropias extends RecyclerView.Adapter<AdaptadorNoticiasPropias.Holder>{

    int contador=0;
    ListasNoticias noticias;
    public AdaptadorNoticiasPropias(ListasNoticias noticias){ this.noticias = noticias;}


    @NonNull
    @Override
    public AdaptadorNoticiasPropias.Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardviewnoticiaspropias, parent, false);
        Holder holder = new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorNoticiasPropias.Holder holder, int position) {
        contador++;
        holder.txttitulo.setText(contador + ". "+noticias.getLista().get(position).getTitulo());

        File imgfile = new File(noticias.getLista().get(position).getRuta());
        if(imgfile.exists()){
            Bitmap myBitmap = BitmapFactory.decodeFile(imgfile.getAbsolutePath());
            holder.imgview.setImageBitmap(myBitmap);
        }

        holder.txtfecha.setText("- "+ noticias.getLista().get(position).getFecha());
    }

    @Override
    public int getItemCount() {
        return noticias.getLista().size();
    }

    public static class Holder extends RecyclerView.ViewHolder{
        TextView txttitulo;
        TextView txtfecha;
        ImageView imgview;

        public Holder(View itemView){
            super(itemView);
            txttitulo = itemView.findViewById(R.id.npTitulo);
            txtfecha = itemView.findViewById(R.id.npFecha);
            imgview = itemView.findViewById(R.id.npFoto);
        }
    }
}
