package com.example.aa;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import kotlin.random.Random;

public class ListaTexto extends AppCompatActivity {


    EditText etText;
    RecyclerView recyclerView;
    ListasNoticias listadenoticias;
    Adaptador adaptador;
    ArrayList<Usuario> listausuarios;
    Usuario usuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_texto);

        //pasar datos

        listadenoticias = (ListasNoticias) getIntent().getSerializableExtra("listanoticias");
        usuario = (Usuario) getIntent().getSerializableExtra("usuario");
        listausuarios = (ArrayList<Usuario>) getIntent().getSerializableExtra("listausuarios");



        inicializar();


    }

    public void inicializar(){
        recyclerView = findViewById(R.id.listatexto);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adaptador =  new Adaptador(listadenoticias);

        recyclerView.setHasFixedSize(true);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adaptador);

        final GestureDetector mGestureDetector = new GestureDetector(ListaTexto.this, new GestureDetector.SimpleOnGestureListener(){
            @Override public boolean onSingleTapUp(MotionEvent e){
                return true;
            }
        });

        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                try {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if(child != null && mGestureDetector.onTouchEvent(e)){
                        int position = recyclerView.getChildAdapterPosition(child);
                        Toast.makeText(ListaTexto.this, "La noticia es: "+listadenoticias.getLista().get(position).getTitulo(), Toast.LENGTH_SHORT).show();

                        Intent pasaractividad = new Intent(ListaTexto.this, VerNoticias.class);
                        pasaractividad.putExtra("noticia", listadenoticias.getLista().get(position));
                        startActivityForResult(pasaractividad, 666);

                        return true;
                    }
                }catch(Exception ex){
                    ex.printStackTrace();
                }


                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 666 && resultCode == RESULT_OK){
        }
    }

    public void devolver(View view) {
        Intent pasaractividad = new Intent(this, MainActivity.class);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        pasaractividad.putExtra("listausuarios", listausuarios);
        pasaractividad.putExtra("usuario", usuario);
        startActivity(pasaractividad);
    }

    @Override
    public void onBackPressed(){
        Intent pasaractividad = new Intent(this, MainActivity.class);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        pasaractividad.putExtra("listausuarios", listausuarios);
        pasaractividad.putExtra("usuario", usuario);
        startActivity(pasaractividad);
    }


}



