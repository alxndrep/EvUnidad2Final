package com.example.aa;

import java.io.Serializable;
import java.util.ArrayList;

public class Usuario implements Serializable {

    private String Usuario;
    private String Contrasena;
    private ListasNoticias misNoticias;


    public Usuario() {
        Usuario = "";
        Contrasena = "";
    }

    public Usuario(String usuario, String contrasena) {
        Usuario = usuario;
        Contrasena = contrasena;
        ListasNoticias lista = new ListasNoticias();
        misNoticias = lista;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String usuario) {
        Usuario = usuario;
    }

    public String getContrasena() {
        return Contrasena;
    }

    public void setContrasena(String contrasena) {
        Contrasena = contrasena;
    }

    public ListasNoticias getMisNoticias() {
        return misNoticias;
    }

    public void setMisNoticias(ListasNoticias misNoticias) {
        this.misNoticias = misNoticias;
    }

}
