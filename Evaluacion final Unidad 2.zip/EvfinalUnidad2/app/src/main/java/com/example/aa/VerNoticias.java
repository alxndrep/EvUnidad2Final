package com.example.aa;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;

public class VerNoticias extends AppCompatActivity {

    TextView notiTitulo, notiFecha, notiDescripcion;
    ImageView notiImagen;
    Button notiButon;
    NoticiasU noticia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_noticias);

        notiTitulo = findViewById(R.id.notiTitulo);
        notiFecha = findViewById(R.id.notiFecha);
        notiDescripcion = findViewById(R.id.notiDescripcion);
        notiImagen = findViewById(R.id.notiFoto);
        notiButon = findViewById(R.id.notiverubicacionbtn);

        noticia = (NoticiasU) getIntent().getSerializableExtra("noticia");

        notiTitulo.setText(noticia.getTitulo());
        notiFecha.setText(noticia.getFecha().toString());
        notiDescripcion.setText(noticia.getTextoNoticias());

        File imgfile = new File(noticia.getRuta());
        if(imgfile.exists()){
            Bitmap myBitmap = BitmapFactory.decodeFile(imgfile.getAbsolutePath());
            notiImagen.setImageBitmap(myBitmap);
        }
    }

    public void verUbicacionMapa(View view){
        Intent pasaractividad = new Intent(VerNoticias.this, VerUbicacion.class);
        pasaractividad.putExtra("latitud", noticia.getLatitud());
        pasaractividad.putExtra("longitud", noticia.getLongitud());
        startActivityForResult(pasaractividad, 10112021);
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 10112021 && resultCode == RESULT_OK){
        }
    }


}