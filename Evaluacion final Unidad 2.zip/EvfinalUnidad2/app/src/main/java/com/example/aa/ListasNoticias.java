package com.example.aa;

import android.util.Log;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;

public class ListasNoticias implements Serializable {
    private ArrayList<NoticiasU> lista;

    public ListasNoticias()
    {
        this.lista = new ArrayList<NoticiasU>();
    }

    public void agregarNoticia(NoticiasU noticia){
        lista.add(noticia);
    }

    public ArrayList<NoticiasU> getLista(){
        return this.lista;
    }

}
