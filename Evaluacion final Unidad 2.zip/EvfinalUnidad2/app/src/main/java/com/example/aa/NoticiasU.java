package com.example.aa;

import com.google.android.gms.maps.model.LatLng;

import java.io.Serializable;
import java.util.Date;

public class NoticiasU implements Serializable {

    private String TextoNoticias;
    private String Titulo;
    private String Ruta;
    private String latitud;
    private String longitud;
    private Date fecha;
    private String autor;

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public NoticiasU() {
        TextoNoticias = "";
        Ruta = "";
        latitud = "";
        longitud = "";
        Titulo = "";
        fecha = null;
        autor = "";
    }

    public NoticiasU(String textoNoticias, String ruta, String latitud, String longitud, String Titulo, Date fecha, String autor) {
        TextoNoticias = textoNoticias;
        Ruta = ruta;
        this.longitud = longitud;
        this.latitud = latitud;
        this.Titulo = Titulo;
        this.fecha = fecha;
        this.autor = autor;
    }

    public String getTextoNoticias() {
        return TextoNoticias;
    }

    public void setTextoNoticias(String textoNoticias) {
        TextoNoticias = textoNoticias;
    }

    public String getRuta() {
        return Ruta;
    }

    public void setRuta(String ruta) {
        Ruta = ruta;
    }

    public String getLatitud() {
        return latitud;
    }

    public void setLatitud(String latitud) {
        this.latitud = latitud;
    }

    public String getLongitud() {
        return longitud;
    }

    public void setLongitud(String longitud) {
        this.longitud = longitud;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }
}
