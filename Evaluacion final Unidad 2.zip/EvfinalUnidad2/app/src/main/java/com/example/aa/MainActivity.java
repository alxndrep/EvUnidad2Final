package com.example.aa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListasNoticias listadenoticias;
    ArrayList<Usuario> listausuarios;
    Usuario usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listausuarios = (ArrayList<Usuario>) getIntent().getSerializableExtra("listausuarios");
        usuario = (Usuario) getIntent().getSerializableExtra("usuario");
        listadenoticias = (ListasNoticias) getIntent().getSerializableExtra("listanoticias");
        if(listadenoticias == null){
            listadenoticias = new ListasNoticias();
        }


    }

    @Override
    public void onBackPressed(){
        actualizarUsuario();
    }
    public void cerrarSesion(View view){
        actualizarUsuario();
    }
    public void actualizarUsuario(){
        for(int i=0; i<listausuarios.size();i++){
            if(listausuarios.get(i).getUsuario().equals(usuario.getUsuario())){
                listausuarios.set(i, usuario);
                break;
            }
        }
        Intent pasaractividad = new Intent(this, Login.class);
        pasaractividad.putExtra("listausuarios", listausuarios);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        startActivity(pasaractividad);
    }

    public void verMisNoticias(View view){
        Intent pasaractividad = new Intent( this, MisNoticias.class);
        pasaractividad.putExtra("usuario", usuario);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        pasaractividad.putExtra("listausuarios", listausuarios);
        startActivity(pasaractividad);
    }

    public void pasaractividadtomarfoto(View view){
        Intent pasaractividad = new Intent(this, TomarFoto.class);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        pasaractividad.putExtra("listausuarios", listausuarios);
        pasaractividad.putExtra("usuario", usuario);
        startActivity(pasaractividad);
    }

    public void verNoticias(View view){
        Intent pasaractividad = new Intent( this, ListaTexto.class);
        pasaractividad.putExtra("listanoticias", listadenoticias);
        pasaractividad.putExtra("listausuarios", listausuarios);
        pasaractividad.putExtra("usuario", usuario);
        startActivity(pasaractividad);
    }
}